# 1 - Import library
import pygame
from pygame.locals import *
import math
import random
import time as t_

# 1.1 - Load images
player_ = pygame.image.load("resources/images/Dudes/dude_with_BearHands.png")
player_shop = pygame.image.load("resources/images/Dudes/dude_with_BearHands.png")
game_icon = pygame.image.load("resources/images/game_logo.png")
game_curser = pygame.image.load("resources/images/curser_img.png")
toggle = pygame.image.load("resources/images/toggle.png")
def Upload_Terrain():
    grass = pygame.image.load("resources/images/Terreain/grass.png")
    wood_floor = pygame.image.load("resources/images/Terreain/wood_floor.png")
    stonewall = pygame.image.load("resources/images/Terreain/stonewall.png")
    blank_wall = pygame.image.load("resources/images/Terreain/blank_wall.png")
    river = pygame.image.load("resources/images/Terreain/river.png")
    lake = pygame.image.load("resources/images/Terreain/lake.png")
    castle = pygame.image.load("resources/images/Terreain/castle.png")
    dark_grass = pygame.image.load("resources/images/Terreain/dark_grass.png")
    city_skyline = pygame.image.load("resources/images/Terreain/CitySkyline.png")
    gravel = pygame.image.load("resources/images/Terreain/gravel.png")
    weapon_seller = pygame.image.load("resources/images/Weapons/weapon_seller.png")
    return player_shop, grass,wood_floor, stonewall, blank_wall, river,lake, castle, dark_grass, city_skyline, gravel,weapon_seller
player_shop ,grass,wood_floor, stonewall, blank_wall, river, lake, castle, drak_grass, city_skyline, gravel,weapon_seller = Upload_Terrain()
def Upload_Allies():
    amiad_body = pygame.image.load("resources/images/Mobs/Amiad/amiad_body.png")
    amiad_head = pygame.image.load("resources/images/Mobs/Amiad/amiad_head.png")
    omer = pygame.image.load("resources/images/Mobs/Omer/omer.png")
    omer_toggled = pygame.image.load("resources/images/Mobs/Omer/omer_toggled.png")
    omer_chair = pygame.image.load("resources/images//Mobs/Omer/omer_chair.png")
    omer_board = pygame.image.load("resources/images/Mobs/Omer/omer_board.png")
    hollander_sober = pygame.image.load("resources/images/Mobs/Hollander/hollander_sober.png")
    hollander_jump = pygame.image.load("resources/images/Mobs/Hollander/hollander_sober_jump.png")
    amir_head = pygame.image.load("resources/images/Mobs/Amir/amir_head.png")
    amir_body = pygame.image.load("resources/images/Mobs/Amir/amir_body.png")
    amir_body_jump = pygame.image.load("resources/images/Mobs/Amir/amir_body_jump.png")
    kabook = pygame.image.load("resources/images/Mobs/Kabook/kabook.png")
    return (amiad_body,amiad_head,omer,omer_toggled,omer_chair,omer_board,hollander_sober,hollander_jump,amir_head,amir_body,amir_body_jump,kabook)
amiad_body,amiad_head,omer,omer_toggled,omer_chair,omer_board,hollander_sober,hollander_jump,amir_head,amir_body,amir_body_jump,kabook = Upload_Allies()
def Upload_Icons():
    hollander_logo = pygame.image.load("resources/images/Icons/hollander_logo.png")
    sharp_logo = pygame.image.load("resources/images/Mobs/Hollander/Moods/Sharp.png")
    slow_logo = pygame.image.load("resources/images/Mobs/Hollander/Moods/Slow.png")
    wavy_logo = pygame.image.load("resources/images/Mobs/Hollander/Moods/Wavy.png")
    kabook_logo = pygame.image.load("resources/images/Icons/kabook_logo.png")
    amir_logo = pygame.image.load("resources/images/Icons/amir_logo.png")
    bit_Coin = pygame.image.load("resources/images/Icons/bitCoin.png")
    omer_logo = pygame.image.load("resources/images/Icons/omer_logo.png")
    healthbar = pygame.image.load("resources/images/Icons/healthbar.png")
    health = pygame.image.load("resources/images/Icons/health.png")
    coin = pygame.image.load("resources/images/Icons/coin.png")
    return (hollander_logo,sharp_logo,slow_logo,wavy_logo,kabook_logo,amir_logo,bit_Coin,omer_logo,healthbar,health,coin)
hollander_logo,sharp_logo,slow_logo,wavy_logo,kabook_logo,amir_logo,bit_Coin,omer_logo,healthbar,health,coin = Upload_Icons()
def Upload_Projectiles():
    #Arrows
    arrow = pygame.image.load("resources/images/Projectiles/Arrows/arrow.png")
    golden_arrow = pygame.image.load("resources/images/Projectiles/Arrows/golden_arrow.png")
    strong_arrow = pygame.image.load("resources/images/Projectiles/Arrows/strong_arrow.png")
    flaming_arrow = pygame.image.load("resources/images/Projectiles/Arrows/flaming_arrow.png")
    #Fists
    fist = pygame.image.load("resources/images/Projectiles/Fists/fist.png")
    bat = pygame.image.load("resources/images/Projectiles/Fists/bat.png")
    sword = pygame.image.load("resources/images/Projectiles/Fists/sword.png")
    axe = pygame.image.load("resources/images/Projectiles/Fists/axe.png")
    #Bling
    gold_coin = pygame.image.load("resources/images/Projectiles/Bling/goldcoin.png")
    blue_cheese = pygame.image.load("resources/images/Projectiles/Bling/blue_cheese.png")
    gold_bar = pygame.image.load("resources/images/Projectiles/Bling/gold_bar.png")
    #Bullets
    regular_bullet = pygame.image.load("resources/images/Projectiles/Bullets/bullet.png")
    golden_bullet = pygame.image.load("resources/images/Projectiles/Bullets/golden_bullet.png")
    strong_bullet = pygame.image.load("resources/images/Projectiles/Bullets/strong_bullet.png")
    pearsing_bullet = pygame.image.load("resources/images/Projectiles/Bullets/pearsing_bullet.png")

    return (arrow,golden_arrow,strong_arrow,flaming_arrow,fist,bat,sword,axe,gold_coin,blue_cheese,gold_bar,regular_bullet,golden_bullet,strong_bullet,pearsing_bullet)
arrow,golden_arrow,strong_arrow,flaming_arrow,\
fist,bat,sword,axe,gold_coin,blue_cheese,gold_bar,\
regular_bullet,golden_bullet,strong_bullet,pearsing_bullet = Upload_Projectiles()
def Upload_BadGuys():
    zombie = pygame.image.load("resources/images/BadGuys/zombie.png")
    big_zombie = pygame.image.load("resources/images/BadGuys/bigzombie.png")
    small_zombie = pygame.image.load("resources/images/BadGuys/small_zombie.png")
    thombstone = pygame.image.load("resources/images/BadGuys/Thombstone.png")
    hand = pygame.image.load("resources/images/BadGuys/hand.png")
    bighand = pygame.image.load("resources/images/BadGuys/bighand.png")
    small_hand = pygame.image.load("resources/images/BadGuys/small_hand.png")
    return zombie,big_zombie,small_zombie,thombstone,hand,bighand,small_hand
zombie,big_zombie,small_zombie,thombstone,hand,bighand,small_hand = Upload_BadGuys()
def Upload_Rest():
    defeat = pygame.image.load("resources/images/defeat.png")
    victory = pygame.image.load("resources/images/victory.png")
    yamero_small = pygame.image.load("resources/images/Mobs/Omer/yamero_small.png")
    yamero_big = pygame.image.load("resources/images/Mobs/Omer/yamero_big.png")
    luffy_img = pygame.image.load("resources/images/Dudes/dude_with_BearHands_luffy.png")
    return defeat,victory,yamero_small,yamero_big,luffy_img
defeat,victory,yamero_small,yamero_big,luffy_img = Upload_Rest()

pygame.mixer.init()
# 1.1.2 - Load audio
hit = pygame.mixer.Sound("resources/audio/explode.wav")
enemy = pygame.mixer.Sound("resources/audio/enemy.wav")
shoot = pygame.mixer.Sound("resources/audio/shoot.wav")
pistol_shot = pygame.mixer.Sound("resources/audio/pistol_shot.wav")
rifle_shot = pygame.mixer.Sound("resources/audio/rifle_shot.wav")
sniper_rifle_shot = pygame.mixer.Sound("resources/audio/sniper_rifle_shot.wav")
bow = pygame.mixer.Sound("resources/audio/bow_shot.wav")
bling_sound = pygame.mixer.Sound("resources/audio/bling_sound.wav")
reload = pygame.mixer.Sound("resources/audio/reload.wav")
arrow_hit_wall = pygame.mixer.Sound("resources/audio/arrow_hit_wall.wav")
swing = pygame.mixer.Sound("resources/audio/swing.wav")
sword_swing = pygame.mixer.Sound("resources/audio/sword.wav")
omer_discovery_sound = pygame.mixer.Sound("resources/audio/omer_discovery.wav")
victory_sound = pygame.mixer.Sound("resources/audio/victory.wav")
defeat_sound = pygame.mixer.Sound("resources/audio/defeat.wav")
player_hurt = pygame.mixer.Sound("resources/audio/player_hurt.wav")
zombie_hurt = pygame.mixer.Sound("resources/audio/zombie_dmg.wav")
zombie_born = pygame.mixer.Sound("resources/audio/zombie_born.wav")
yamete = pygame.mixer.Sound("resources/audio/yamero.wav")
amir_sound = pygame.mixer.Sound("resources/audio/amir_sound.wav")
kabook_sound = pygame.mixer.Sound("resources/audio/kabook_sound.wav")
hollander_sound = pygame.mixer.Sound("resources/audio/hollander_sound.wav")
omer_sound = pygame.mixer.Sound("resources/audio/omer_sound.wav")
amiad_sound = pygame.mixer.Sound("resources/audio/amiad_sound.wav")

hit.set_volume(0.05)
enemy.set_volume(0.05)
shoot.set_volume(0.05)
pistol_shot.set_volume(0.10)
rifle_shot.set_volume(0.15)
rifle_shot.set_volume(0.3)
bow.set_volume(0.15)
arrow_hit_wall.set_volume(0.15)
swing.set_volume(0.15)
sword_swing.set_volume(0.15)
omer_discovery_sound.set_volume(0.2)
victory_sound.set_volume(0.9)
defeat_sound.set_volume(0.9)
player_hurt.set_volume(0.05)
zombie_hurt.set_volume(0.05)
zombie_born.set_volume(0.05)
yamete.set_volume(0.9)
reload.set_volume(0.2)
bling_sound.set_volume(0.05)
amir_sound.set_volume(0.05)
kabook_sound.set_volume(0.05)
hollander_sound.set_volume(0.05)
omer_sound.set_volume(0.2)
amiad_sound.set_volume(0.2)

pygame.mixer.music.load('resources/audio/Themes_Song.wav')
pygame.mixer.music.play(-1, 0.0)
pygame.mixer.music.set_volume(0.2)

#ButtonSmooverPress
class Clickers():
    def __init__(self):
        self.timer = 0
        self.timer_b = 0
        self.timer_q = 0
        self.timer_e = 0
        self.timer_g = 0
        self.timer_1 = 0
        self.timer_2 = 0
        self.delta = 3
    def Click(self):
        self.timer +=1
    def GetClick(self):
        return self.timer

    def CheckB(self):
        if (self.timer-self.timer_b) > self.delta:
            self.timer_b = self.timer
            self.timer += 1
            return True
        self.timer_b = self.timer
        self.timer +=1
        return False
    def CheckQ(self):
        if (self.timer-self.timer_q) >  self.delta:
            self.timer_q = self.timer
            self.timer += 1
            return True
        self.timer_q = self.timer
        self.timer +=1
        return False
    def CheckE(self):
        if (self.timer-self.timer_e) >  self.delta:
            self.timer_e = self.timer
            self.timer += 1
            return True
        self.timer_e = self.timer
        self.timer +=1
        return False
    def CheckG(self):
        if (self.timer-self.timer_g) >  self.delta:
            self.timer_g = self.timer
            self.timer += 1
            return True
        self.timer_g = self.timer
        self.timer +=1
        return False
    def Check1(self):
        if (self.timer-self.timer_1) >  self.delta:
            self.timer_1 = self.timer
            self.timer += 1
            return True
        self.timer_1 = self.timer
        self.timer +=1
        return False
    def Check2(self):
        if (self.timer-self.timer_2) >  self.delta:
            self.timer_2 = self.timer
            self.timer += 1
            return True
        self.timer_2 = self.timer
        self.timer +=1
        return False
class Time():
    burn_factor = 0.1
    wave_factor = 3
    def __init__(self):
        self.clock = 0
    def Tick(self):
        self.clock +=1
    def DoTick(self,object1):
        if(object1.state is None):
            pass
        else:
            if(object1.state[1] <= 0):
                object1.state = None
            else:
                if(object1.state[0] == "Burn"):
                    #fire dmg sound
                    hit.play()
                    self.Burn(object1)
                elif(object1.state[0] == "Wavy"):
                    self.Wavy(object1)
                object1.state = (object1.state[0], object1.state[1] - 1)
    def Burn(self,object1):
        object1.hp -= Time.burn_factor
    def Wavy(self,object1):
        x_,y_ = object1.pos
        x_ = x_ + random.randint(0,Time.wave_factor) - random.randint(0,Time.wave_factor)
        y_ = y_ + random.randint(0,Time.wave_factor) - random.randint(0,Time.wave_factor)
        object1.pos = (x_,y_)

# 1.2 Characters
class MainPlayer():
    def __init__(self, width, height):
        self.pos = [width / 2, height - 50]
        self.hp = 408
        self.baseImg = player_
        self.currentImg = self.baseImg
        self.vel = 3
        self.current_vel = self.vel
        self.wallet = 2000
        self.toggled = None
        self.bag = Bag([BearHands(),Regular_Bow()], [Hollander,Kabook,Amir])
        self.current_weapon = self.bag.GetCurrentWeapon()
        self.UpdateBaseImage()
        self.current_mob = self.bag.GetCurrentMob(self)
        self.state = None
    def UpdateBaseImage(self):
        if(self.current_weapon.current_ammo == "luffy_"):
            self.baseImg = luffy_img
        else:
            self.baseImg = pygame.image.load("resources/images/Dudes/dude_with_" + self.current_weapon.weapon + ".png")
    def UpdateCurrImage(self, curserPos):
        self.UpdateBaseImage()
        self.currentImg = GetRotatedImg(GetAngle(self.pos, curserPos), self.baseImg)
    def CheckPos(self, x_, y_, obstacles):
        moveY = False
        moveX = False
        slowFactor = 1
        for swamp in [x for x in obstacles if "Slow" in x.traits]:
            if (CheckForCollisionObject(self, swamp)):
                slowFactor = swamp.slow
            elif (type(swamp) == Lake) and (CheckForCollisionCircle(self, swamp)):
                slowFactor = swamp.slow
        for stream in [x for x in obstacles if "Flowing" in x.traits]:
            if (CheckForCollisionObject(self, stream)):
                stream.Drift(self)

        for wall in [x for x in obstacles if "Solid" in x.traits]:
            if (CheckForCollisionObject(self, wall)):
                widthC = self.currentImg.get_rect()[2]
                heightC = self.currentImg.get_rect()[3]
                heightW = wall.rect[3]
                if (self.pos[0] > int(wall.span[0] - widthC) and self.pos[0] < int(wall.span[1] + widthC)):
                    if (self.pos[1] > wall.y) and (y_ < 0):
                        moveY = True
                    elif (self.pos[1] < wall.y) and (y_ > 0):
                        moveY = True
                elif (self.pos[1] > int(wall.y - heightW) and self.pos[1] < int(wall.y + heightW)):
                    if (self.pos[0] <= wall.rect[0] + 50) and (x_ > 0):
                        moveX = True
                    elif (self.pos[0] > wall.span[0] + 50) and (x_ < 0):
                        moveX = True
        return ((moveX, moveY), slowFactor)
    def UpdatePos(self, x, y, obstacles):
        indicator, slowFactor = MainPlayer.CheckPos(self, x, y, obstacles)
        newX, newY = self.pos
        if not (indicator[0]):
            newX = self.pos[0] + x * slowFactor
        if not (indicator[1]):
            newY = self.pos[1] + y * slowFactor
        if IfInbound((newX,newY)):
            self.pos = (newX, newY)
    def UpdateWalletKill(self, rate=1):
        self.wallet += int(random.gauss(5, 2) * rate + 1)
    def UpdateWallet(self, sum):
        self.wallet += sum
    def GetHit(self,dmg):
        player_hurt.play()
        self.hp -= dmg

class Character():
    def __init__(self, pos, vel,baseImg,hp):
        self.pos = pos
        self.baseImg = baseImg
        self.currentImg = self.baseImg
        self.vel = vel
        self.hp = hp
        self.rate = 0
        self.state = None

    def move(self, objectPos, obstacles):
        slowFactor = 1
        for swamp in [x for x in obstacles if "Slow" in x.traits]:
            if (CheckForCollisionObject(self, swamp)):
                slowFactor = swamp.slow
            elif (type(swamp) == Lake) and (CheckForCollisionCircle(self, swamp)):
                slowFactor = swamp.slow
        for stream in [x for x in obstacles if "Flowing" in x.traits]:
            if (CheckForCollisionObject(self, stream)):
                stream.Drift(self)

        for wall in [x for x in obstacles if "Solid" in x.traits]:
            if (CheckForCollisionObject(self, wall)):
                if (wall.y in range(int(min(objectPos[1], self.pos[1])), int(max(objectPos[1], self.pos[1])))) and not (
                        self.pos[0] in range(wall.span[0], wall.span[1])):
                    direction = wall.GiveBestPath(self)
                    self.pos = (self.pos[0] + direction * self.vel * slowFactor, self.pos[1])
                    self.currentImg = GetRotatedImg(GetAngle(self.pos, (self.pos[0] + direction, self.pos[1])),
                                                    self.baseImg)
                    return (True, slowFactor)
        return (False, slowFactor)

    def hit(self,player,dmg):
        #hit.play()
        player.GetHit(dmg)

    def GetHit(self, dmg):
        self.hp -= dmg
        return self.hp > 0
    def Draw(self):
        screen.blit(self.currentImg, self.pos)
#BadGuys
class BadGuy(Character):
    def __init__(self, pos,vel,dmg,baseImg,hp):
        super().__init__(pos,vel,baseImg,hp)
        self.dmg = dmg
        self.rate = random.randint(5,20)
    def move(self, objectPos, osbtacles):
        temp = super().move(objectPos, osbtacles)
        if not temp[0]:
            self.pos = MoveObject1TowordsObject2(self.pos, objectPos, self.vel * temp[1])
            self.currentImg = GetRotatedImg(GetAngle(self.pos, objectPos), self.baseImg)
    def hit(self,player):
        super().hit(player,random.randint(self.dmg-self.dmg//2,self.dmg+ self.dmg//2))
        x_,y_ = GetMovementVector(GetAngle(self.pos,player.pos),self.dmg*5)
        if IfInbound((player.pos[0] + x_ , player.pos[1] + y_)):
            player.pos = (player.pos[0] + x_ , player.pos[1] + y_)

    def GetHit(self, dmg):
        zombie_hurt.play()
        super().GetHit(dmg)
class Thombstone (BadGuy):
    def __init__(self,pos):
        super().__init__(pos, 0, 0, thombstone, 20)
        self.rate = 0
    def move(self,*args):
        pass
    def hit(self,*args):
        pass
    def GetHit(self,dmg):
        self.hp -=1
    def Draw(self):
        screen.blit(self.baseImg,self.pos)
    def GenerateZombie(self):
        r = random.randint(0,9000)
        if(r < 10):
            zombie_born.play()
            z = Zombie(self.pos)
            self.GetHit(1)
            return z
        if(r==420):
            zombie_born.play()
            z= BigZombie(self.pos)
            self.GetHit(3)
            return z
        if(r>=369 and r <=371):
            zombie_born.play()
            z= SmallZombie(self.pos)
            self.GetHit(1)
            return z
class Zombie(BadGuy):
    def __init__(self, pos):
        super().__init__(pos,0.7,5,zombie,random.randint(15,25))
        self.pause = 200
    def move(self, objectPos, obstacles):
        if(self.pause > 0):
            self.pause -= 1
        else:
            slowFactor = 1
            indicator = False
            for swamp in [x for x in obstacles if "Slow" in x.traits]:
                if (CheckForCollisionObject(self, swamp)):
                    slowFactor = swamp.slow
                elif (type(swamp) == Lake) and (CheckForCollisionCircle(self, swamp)):
                    slowFactor = swamp.slow
            for stream in [x for x in obstacles if "Flowing" in x.traits]:
                if (CheckForCollisionObject(self, stream)):
                    stream.Drift(self)
            for wall in [x for x in obstacles if "Solid" in x.traits]:
                if (CheckForCollisionObject(self, wall)):
                    if (wall.y in range(int(min(objectPos[1], self.pos[1])),
                                        int(max(objectPos[1], self.pos[1])))) and not (
                            self.pos[0] in range(wall.span[0], wall.span[1])):
                        direction = wall.GiveBestPath(self)
                        self.pos = (self.pos[0] + direction * self.vel * slowFactor, self.pos[1])
                        self.currentImg = GetRotatedImg(GetAngle(self.pos, (self.pos[0] + direction, self.pos[1])),
                                                        self.baseImg)
                        indicator = True
            for amir in [x for x in obstacles if "Creepy" in x.traits]:
                if(CheckDistance(self.pos,amir.pos) <= 200):
                    x_,y_ = GetMovementVector(GetAngle(amir.pos,self.pos),self.vel*3)
                    self.pos = (self.pos[0] + x_,self.pos[1] + y_)
                    indicator = True
            if not(indicator):
                self.pos = MoveObject1TowordsObject2(self.pos, objectPos, self.vel * slowFactor)
                self.currentImg = GetRotatedImg(GetAngle(self.pos, objectPos), self.baseImg)
    def hit(self,*args):
        if(self.pause <= 0):
            super().hit(*args)
    def GetHit(self,dmg):
        if (self.pause <= 0):
            super().GetHit(dmg)
    def Draw(self):
        if (self.pause > 0):
            screen.blit(hand, self.pos)
        else:
            super().Draw()
class BigZombie(BadGuy):
    def __init__(self, pos):
        super().__init__(pos,0.3,20,big_zombie,random.randint(300,400))
        self.pause = 300
    def move(self,*args):
        if(self.pause > 0):
            self.pause -= 1
        else:
            super().move(*args)
    def hit(self,*args):
        if(self.pause <= 0):
            super().hit(*args)

    def GetHit(self,dmg):
        if (self.pause <= 0):
            super().GetHit(dmg)
    def Draw(self):
        if (self.pause > 0):
            screen.blit(bighand, self.pos)
        else:
            super().Draw()
class SmallZombie(BadGuy):
    def __init__(self, pos):
        super().__init__(pos,2,4,small_zombie,random.randint(40,75))
        self.pause = 200
    def move(self,*args):
        if(self.pause > 0):
            self.pause -= 1
        else:
            super().move(*args)
    def hit(self,*args):
        if(self.pause <= 0):
            super().hit(*args)
    def GetHit(self,dmg):
        if (self.pause <= 0):
            super().GetHit(dmg)
    def Draw(self):
        if (self.pause > 0):
            screen.blit(small_hand, (self.pos[0]+20,self.pos[1]+30))
        else:
            super().Draw()
#GoodGuys
class Hollander(Character):
    def __init__(self,pos):
        super().__init__(pos,4,hollander_sober,100)
        self.current_vel = self.vel
        self.rate = -50
        self.state = None
        self.sober = True
        self.drug = None
        self.list_of_drugs = ["green", "white", "red"]
        self.sound = True

    def GetDrug(self):
        self.drug = self.list_of_drugs[random.randint(0, len(self.list_of_drugs) - 1)]
    def GetHigh(self):
        self.GetDrug()
        self.sober = False
        UseDrug(self, self.drug)
        self.sound = False
    def DrawEffect(self):
        x = self.GetStateIcon()
        if(x is not None):
            screen.blit(x, (000,40))
    def GetStateIcon(self):
        if(self.state is None):
            return None
        if(self.state[0] == "Slow"):
            return slow_logo
        if(self.state[0] == "Sharp"):
            return sharp_logo
        if(self.state[0] == "Wavy"):
            return wavy_logo

    def move(self,player_pos, obstacles):
        if (self.sober):
            if (self.pos[0] <= width + 100):
                if(self.sound):
                    hollander_sound.play()
                    self.sound = False
                self.pos = (self.pos[0] + self.vel, self.pos[1])
            else:
                self.GetHigh()
        else:
            slowFactor = 1
            for swamp in [x for x in obstacles if "Slow" in x.traits]:
                if (CheckForCollisionObject(self, swamp)):
                    slowFactor = swamp.slow
                elif (type(swamp) == Lake) and (CheckForCollisionCircle(self, swamp)):
                    slowFactor = swamp.slow
            for stream in [x for x in obstacles if "Flowing" in x.traits]:
                if (CheckForCollisionObject(self, stream)):
                    stream.Drift(self)
            collision_flag = False
            for wall in [x for x in obstacles if "Solid" in x.traits]:
                if (CheckForCollisionObject(self, wall)):
                    collision_flag = True
                    self.jump()
            if not (collision_flag):
                self.land()
            self.pos = MoveObject1TowordsObject2(self.pos, player_pos, self.current_vel)
            self.currentImg = RotateImgTowardsPlayer(player_pos, self.pos, self.baseImg)[0]
            self.DrawEffect()
    def jump(self):
        self.current_vel = self.vel * 0.5
        self.baseImg = hollander_jump
    def land(self):
        self.current_vel = self.vel
        self.baseImg = hollander_sober
    def hit(self,player):
        self.sober = True
        self.sound = True
        self.current_vel = self.vel
        UseDrug(player,self.drug)
    def Draw(self):
        screen.blit(self.currentImg, self.pos)
        if(self.state is not None):
            self.DrawEffect()
class Amir(Character):
    def __init__(self,pos,L):
        super().__init__(pos,3,amir_head,500)
        self.current_vel = self.vel
        self.rate = 0
        self.targets = L
        self.target = self.GetTarget()
        self.staticImg = amir_body
        self.traits = "Creepy"
    def jump(self):
        self.current_vel = self.vel * 0.5
        self.staticImg = amir_body_jump
    def land(self):
        self.current_vel = self.vel
        self.staticImg = amir_body
    def move(self, objectPos, obstacles):
        slowFactor = 1
        if(self.target is None):
            self.target = self.GetTarget()
        if(self.target is not None) and (self.target.hp <= 0):
            self.target = None
        if(self.target is not None):
            for swamp in [x for x in obstacles if "Slow" in x.traits]:
                if (CheckForCollisionObject(self, swamp)):
                    slowFactor = swamp.slow
                elif (type(swamp) == Lake) and (CheckForCollisionCircle(self, swamp)):
                    slowFactor = swamp.slow
            for stream in [x for x in obstacles if "Flowing" in x.traits]:
                if (CheckForCollisionObject(self, stream)):
                    stream.Drift(self)
            collision_flag = False
            for wall in [x for x in obstacles if "Solid" in x.traits]:
                if (CheckForCollisionObject(self, wall)):
                    collision_flag = True
                    self.jump()
            if not(collision_flag):
                self.land()
            self.pos = MoveObject1TowordsObject2(self.pos, self.target.pos, self.current_vel)
        else:
            self.target = self.GetTarget()


        return (False, slowFactor)
    def GetTarget(self):
        if len(self.targets) !=  0:
            temp =  self.targets[(random.randint(0,len(self.targets)-1))]
            if type(temp) is Thombstone:
                return None
            else:
                return temp
        return None
    def GetCurrentTarget(self):
        return self.target
    def hit(self,object1):
        if (object1 in self.targets) and (object1.pause == 0):
            amir_sound.play()
            super().hit(object1,object1.hp + 1)
            self.target = self.GetTarget()
            self.GetHit(100)
    def Draw(self):
        screen.blit(self.currentImg, self.pos)
        screen.blit(self.staticImg,(self.pos[0]+3,self.pos[1]+40))
class Kabook(Character):
    def __init__(self,pos,curser):
        super().__init__(pos,20,kabook,1)
        self.rate = 0
        self.current_vel = self.vel
        self.angle = GetAngle(pos,curser)
        self.currentImg = kabook#GetRotatedImg(self.angle,self.baseImg)
        self.speed_decay = 0.97

    def move(self,junk1,junk2):
        movement_vector = GetMovementVector(self.angle,self.current_vel)
        self.pos = (self.pos[0]+movement_vector[0],self.pos[1] + movement_vector[1])
        self.current_vel = self.current_vel*self.speed_decay
        if(self.current_vel <=10**-2):
            self.hp = -1
    def hit(self,object1):
        if(type(object1) is MainPlayer):
            pass
        else:
            kabook_sound.play()
            super().hit(object1,500)
    def GetHit(self, dmg):
        pass

def UseDrug(user,drug):
    if(drug == "green"):
        user.GetHit(1)
        user.current_vel = user.current_vel*0.7
        user.state = ("Slow",1000)
    elif(drug == "white"):
        user.GetHit(7)
        user.current_vel = user.current_vel*1.25
        user.state = ("Sharp",500)
    elif(drug == "red"):
        user.GetHit(2)
        user.current_vel = user.current_vel*1.1
        user.state = ("Wavy",900)
# 1.3 Projectiles and Weapons
# 1.3.0 Projectiles
class Projectile():
    def __init__(self, player, curser, vel,dmg,range,baseImg,deathTimer = 100):
        self.angle = math.atan2(curser[1] - (player.pos[1] + 32), curser[0] - (player.pos[0] + 26))
        self.pos = [player.pos[0] + 32, player.pos[1] + 32]
        self.vel = vel
        self.deathTimer = deathTimer
        self.dmg = dmg
        self.baseImg = baseImg
        self.currentImg = GetRotatedImg(self.angle, self.baseImg)
        self.range = range
        self.delta_r = 0

    def move(self, obstacles, projectiles, mobs_list, index):
        if not IfInbound(self.pos):
            projectiles.pop(index)
            return True
        if (self.deathTimer <= 0):
            projectiles.pop(index)
            return True
        if (self.vel == 0):
            self.deathTimer -= 1
        if(self.delta_r >= self.range):
            self.vel = 0
        for wall in [x for x in obstacles if "Solid" in x.traits]:
            if (CheckForCollisionObject(self, wall)):
                self.vel = 0
        for mob in mobs_list:
            if CheckForCollision(self, mob):
                enemy.play()
                projectiles.pop(index)
                if(mob.GetHit(GenerateDmg(self))):
                    mobs_list.remove(mob)
                return True
        velx, vely = GetMovementVector(self.angle, self.vel)
        self.pos[0] += velx
        self.pos[1] += vely
        self.delta_r += self.vel
        return False
    def Draw(self):
        screen.blit(self.currentImg, self.pos)
#Arrows
class Arrow(Projectile):
    def __init__(self, player, curser):
        super().__init__(player, curser,15,10,700,baseImg = arrow)
    def move(self, obstacles, projectiles, mobs_list, index):
        if not IfInbound(self.pos):
            projectiles.pop(index)
            return True
        if (self.deathTimer <= 0):
            projectiles.pop(index)
            return True
        if (self.vel == 0):
            self.deathTimer -= 1
        if(self.delta_r >= self.range):
            self.vel = 0
        for wall in [x for x in obstacles if "Solid" in x.traits]:
            if (CheckForCollisionObject(self, wall)):
                arrow_hit_wall.play()
                self.vel = 0
        for mob in mobs_list:
            if CheckForCollision(self, mob):
                enemy.play()
                projectiles.pop(index)
                if(mob.GetHit(GenerateDmg(self))):
                    mobs_list.remove(mob)
                return True
        velx, vely = GetMovementVector(self.angle, self.vel)
        self.pos[0] += velx
        self.pos[1] += vely
        self.delta_r += self.vel
        return False
class GoldenArrow(Projectile):
    def __init__(self, player, curser):
        super().__init__(player, curser, 15, 12,700,baseImg = golden_arrow)
    def move(self, obstacles, projectiles, mobs_list, index):
        if not IfInbound(self.pos):
            projectiles.pop(index)
            return True
        if (self.deathTimer <= 0):
            projectiles.pop(index)
            return True
        if (self.vel == 0):
            self.deathTimer -= 1
        if(self.delta_r >= self.range):
            self.vel = 0
        for wall in [x for x in obstacles if "Solid" in x.traits]:
            if (CheckForCollisionObject(self, wall)):
                arrow_hit_wall.play()
                self.vel = 0
        for mob in mobs_list:
            if CheckForCollision(self, mob):
                enemy.play()
                projectiles.pop(index)
                if(mob.GetHit(GenerateDmg(self))):
                    mobs_list.remove(mob)
                return True
        velx, vely = GetMovementVector(self.angle, self.vel)
        self.pos[0] += velx
        self.pos[1] += vely
        self.delta_r += self.vel
        return False
class StrongArrow(Projectile):
    def __init__(self, player, curser):
        super().__init__(player, curser, 13, 20,700,baseImg = strong_arrow)
    def move(self, obstacles, projectiles, mobs_list, index):
        if not IfInbound(self.pos):
            projectiles.pop(index)
            return True
        if (self.deathTimer <= 0):
            projectiles.pop(index)
            return True
        if (self.vel == 0):
            self.deathTimer -= 1
        if(self.delta_r >= self.range):
            self.vel = 0
        for wall in [x for x in obstacles if "Solid" in x.traits]:
            if (CheckForCollisionObject(self, wall)):
                arrow_hit_wall.play()
                self.vel = 0
        for mob in mobs_list:
            if CheckForCollision(self, mob):
                enemy.play()
                projectiles.pop(index)
                if(mob.GetHit(GenerateDmg(self))):
                    mobs_list.remove(mob)
                return True
        velx, vely = GetMovementVector(self.angle, self.vel)
        self.pos[0] += velx
        self.pos[1] += vely
        self.delta_r += self.vel
        return False
class FlamingArrow(Projectile):
    def __init__(self, player, curser):
        super().__init__(player, curser, 12, 12,500,baseImg = flaming_arrow)
    def move(self, obstacles, projectiles, mobs_list, index):
        if not IfInbound(self.pos):
            projectiles.pop(index)
            return True
        if (self.deathTimer <= 0):
            projectiles.pop(index)
            return True
        if (self.vel == 0):
            self.deathTimer -= 1
        if(self.delta_r >= self.range):
            self.vel = 0
        for wall in [x for x in obstacles if "Solid" in x.traits]:
            if (CheckForCollisionObject(self, wall)):
                arrow_hit_wall.play()
                self.vel = 0
        for mob in mobs_list:
            if CheckForCollision(self, mob):
                zombie_hurt.play()
                projectiles.pop(index)
                if(mob.GetHit(GenerateDmg(self))):
                    mobs_list.remove(mob)
                else:
                    mob.state = ("Burn",200)
                return True
        velx, vely = GetMovementVector(self.angle, self.vel)
        self.pos[0] += velx
        self.pos[1] += vely
        self.delta_r += self.vel
        return False
#Hands
class Fist(Projectile):
    def __init__(self,player,curser):
        super().__init__(player,curser,20,3,40,fist,3)
class Bat(Projectile):
    def __init__(self,player,curser):
        super().__init__(player,curser,5,5,80,bat,10)
class Sword(Projectile):
    def __init__(self,player,curser):
        super().__init__(player,curser,5,15,120,sword,30)
class Axe(Projectile):
    def __init__(self, player, curser):
        super().__init__(player, curser, 5, 20, 80, axe, 50)
class Luffy(Projectile):
    def __init__(self, player, curser):
        super().__init__(player, curser, 5, 150, 750, fist, 50)
#bullets
class Bullet(Projectile):
    def __init__(self, player, curser):
        super().__init__(player, curser, 30, 20, 1000, baseImg=regular_bullet)
class GoldenBullet(Projectile):
    def __init__(self, player, curser):
        super().__init__(player, curser, 30, 22, 1200, baseImg=golden_bullet)
class StrongBullet(Projectile):
    def __init__(self, player, curser):
        super().__init__(player, curser, 30, 30, 1300, baseImg=strong_bullet)
class PearcingBullet(Projectile):
    def __init__(self, player, curser):
        super().__init__(player, curser, 30, 5, 1000, baseImg=pearsing_bullet)


    def move(self, obstacles, projectiles, mobs_list, index):
        if not IfInbound(self.pos):
            projectiles.pop(index)
            return True
        if (self.deathTimer <= 0):
            projectiles.pop(index)
            return True
        if (self.vel == 0):
            self.deathTimer -= 1
        if(self.delta_r >= self.range):
            self.vel = 0
        for wall in [x for x in obstacles if "Solid" in x.traits]:
            if (CheckForCollisionObject(self, wall)):
                self.vel = 0
        for mob in mobs_list:
            if CheckForCollision(self, mob):
                pistol_shot.play()
                if(mob.GetHit(GenerateDmg(self))):
                    mobs_list.remove(mob)
        velx, vely = GetMovementVector(self.angle, self.vel)
        self.pos[0] += velx
        self.pos[1] += vely
        self.delta_r += self.vel
        return False
#Bling
class GoldCoin(Projectile):
    def __init__(self, player, curser):
        super().__init__(player, curser, 5,5,200,gold_coin)
        self.pos = [player.pos[0] + 32, player.pos[1] + 32]
        self.bounce = False
        self.deathTimer = 500
    def move(self, obstacles, projectiles,mobs_list ,index):
        if not IfInbound(self.pos):
            projectiles.pop(index)
            return True
        if (self.deathTimer <= 0):
            projectiles.pop(index)
            return True
        if (self.vel == 0):
            self.deathTimer -= 1
        if(self.delta_r >= self.range):
            self.vel = 0
        for wall in [x for x in obstacles if "Solid" in x.traits]:
            if (CheckForCollisionObject(self, wall)):
                self.vel = -1*self.vel
                self.bounce = True
        for mob in mobs_list:
            if CheckForCollision(self, mob):
                if(self.dmg != 0):
                    enemy.play()
                    self.vel = -1 * self.vel
                    self.bounce = True
                    if (mob.GetHit(GenerateDmg(self))):
                        mobs_list.remove(mob)
                    self.dmg = 0
                else:
                    self.vel = -1 * self.vel
                    self.bounce = True

        if(self.bounce):
            self.dmg = 0
            if(self.vel**2 < 10**-50):
                self.vel = 0
            else:
                self.vel = 0.8*self.vel

        velx, vely = GetMovementVector(self.angle, self.vel)
        self.pos[0] += velx
        self.pos[1] += vely

        velx, vely = GetMovementVector(self.angle, self.vel)
        self.pos[0] += velx
        self.pos[1] += vely
        self.delta_r += self.vel
        return False
class BlueCheese(Projectile):
    def __init__(self, player, curser):
        super().__init__(player, curser, 5,20,200,blue_cheese,500)
        self.pos = [player.pos[0] + 32, player.pos[1] + 32]
        self.bounce = False
    def move(self, obstacles, projectiles,mobs_list ,index):
        if not IfInbound(self.pos):
            projectiles.pop(index)
            return True
        if (self.deathTimer <= 0):
            projectiles.pop(index)
            return True
        if (self.vel == 0):
            self.deathTimer -= 1
        if(self.delta_r >= self.range):
            self.vel = 0
        for wall in [x for x in obstacles if "Solid" in x.traits]:
            if (CheckForCollisionObject(self, wall)):
                self.vel = -1*self.vel
                self.bounce = True
        for mob in mobs_list:
            if CheckForCollision(self, mob):
                if(self.dmg != 0):
                    enemy.play()
                    self.vel = -1 * self.vel
                    self.bounce = True
                    if (mob.GetHit(GenerateDmg(self))):
                        mobs_list.remove(mob)
                    self.dmg = 0
                else:
                    self.vel = -1 * self.vel
                    self.bounce = True

        if(self.bounce):
            self.dmg = 0
            if(self.vel**2 < 10**-50):
                self.vel = 0
            else:
                self.vel = 0.8*self.vel

        velx, vely = GetMovementVector(self.angle, self.vel)
        self.pos[0] += velx
        self.pos[1] += vely

        velx, vely = GetMovementVector(self.angle, self.vel)
        self.pos[0] += velx
        self.pos[1] += vely
        self.delta_r += self.vel
        return False
class GoldBar(Projectile):
    def __init__(self, player, curser):
        super().__init__(player, curser, 5,100,200,gold_bar,500)
        self.pos = [player.pos[0] + 32, player.pos[1] + 32]
        self.bounce = False
    def move(self, obstacles, projectiles,mobs_list ,index):
        if not IfInbound(self.pos):
            projectiles.pop(index)
            return True
        if (self.deathTimer <= 0):
            projectiles.pop(index)
            return True
        if (self.vel == 0):
            self.deathTimer -= 1
        if(self.delta_r >= self.range):
            self.vel = 0
        for wall in [x for x in obstacles if "Solid" in x.traits]:
            if (CheckForCollisionObject(self, wall)):
                self.vel = -1*self.vel
                self.bounce = True
        for mob in mobs_list:
            if CheckForCollision(self, mob):
                if(self.dmg != 0):
                    enemy.play()
                    self.vel = -1 * self.vel
                    self.bounce = True
                    if (mob.GetHit(GenerateDmg(self))):
                        mobs_list.remove(mob)
                    self.dmg = 0
                else:
                    self.vel = -1 * self.vel
                    self.bounce = True

        if(self.bounce):
            self.dmg = 0
            if(self.vel**2 < 10**-50):
                self.vel = 0
            else:
                self.vel = 0.8*self.vel

        velx, vely = GetMovementVector(self.angle, self.vel)
        self.pos[0] += velx
        self.pos[1] += vely

        velx, vely = GetMovementVector(self.angle, self.vel)
        self.pos[0] += velx
        self.pos[1] += vely
        self.delta_r += self.vel
        return False

def GetProjectile(name):
    if(name[-1] == 'w'):#Arrows
        if(name == "arrow"):
            return Arrow
        elif(name == "gold_arrow"):
            return GoldenArrow
        elif(name == "strong_arrow"):
            return StrongArrow
        elif(name == "flaming_arrow"):
            return FlamingArrow
    elif(name[-1] == '_'):
        if(name == "fist_"):
            return Fist
        elif(name == "bat_"):
            return Bat
        elif(name == "sword_"):
            return Sword
        elif(name == "axe_"):
            return Axe
        elif(name == "luffy_"):
            return Luffy
    elif(name[-1] == 't'):
        if(name == "regular_bullet"):
            return Bullet
        if(name =="gold_bullet" ):
            return GoldenBullet
        if(name == "strong_bullet"):
            return StrongBullet
        if(name == "pearsing_bullet"):
            return PearcingBullet
    elif(name == "gold_coin"):
        return GoldCoin
    elif (name == "blue_cheese"):
        return BlueCheese
    elif(name == "gold_bar"):
        return GoldBar
    return None
def GenerateDmg(projectile):
    return int(random.gauss(projectile.dmg - 2, 4) + 2)

# 1.3.5 - WeaponsFunctions

class Weapon():

    def __init__(self, weapon, vel, dmg,current_ammo,reload_time,magazine_size):
        self.weapon = weapon
        self.vel = vel
        self.dmg = dmg
        self.current_ammo = current_ammo
        self.reload_time = reload_time
        self.current_reload_time = 0
        self.magazine_size = magazine_size
        self.current_magazine = magazine_size
        self.pause = False

    def Reload(self):
        if self.current_reload_time > 1:
            self.current_reload_time -= 1
        else:
            self.current_magazine = self.magazine_size
            self.current_reload_time = 0
            self.pause = False
    def StartReloading(self):
        #reload.play()
        self.current_reload_time = self.reload_time
        self.pause = True
        self.Reload()
    def IsReloading(self):
        return self.current_reload_time > 0

    def Shoot(self,player,curser,projectiles):
        if not self.pause:
            self.current_magazine -= 1
            temp_proj = GetProjectile(self.current_ammo)(player,curser)
            projectiles.append(temp_proj)
        else:
            pass#add  reload_shot.play()
class Regular_Bow(Weapon):
    def __init__(self):
        super().__init__("Regular_Bow", 1,1,"arrow",2,3)
    def Shoot(self,*args):
        bow.play()
        super().Shoot(*args)
class Cross_Bow(Weapon):
    def __init__(self):
        super().__init__("Cross_Bow", 1.2,1.2,"arrow",3,5)
    def Shoot(self,*args):
        bow.play()
        super().Shoot(*args)
class Pistol(Weapon):
    def __init__(self):
        super().__init__("Pistol",1,1,"regular_bullet",3,10)
    def Shoot(self,*args):
        pistol_shot.play()
        super().Shoot(*args)
    def StartReloading(self):
        reload.play()
        super().StartReloading()
class Rifle(Weapon):
    def __init__(self):
        super().__init__("Rifle",1.5,1.5,"regular_bullet",5,29)
    def Shoot(self,*args):
        rifle_shot.play()
        super().Shoot(*args)
    def StartReloading(self):
        reload.play()
        super().StartReloading()
class SniperRifle(Weapon):
    def __init__(self):
        super().__init__("SniperRifle",2,10,"regular_bullet",10,5)
    def Shoot(self,*args):
        sniper_rifle_shot.play()
        super().Shoot(*args)
    def StartReloading(self):
        reload.play()
        super().StartReloading()
class GoldHands(Weapon):
    def __init__(self):
        super().__init__("GoldHands", 40,1, "gold_coin",300,19)
    def Shoot(self,player,curser,projectiles):
        #player.UpdateWallet(-5)
        bling_sound.play()
        super().Shoot(player,curser,projectiles)
class BearHands(Weapon):
    def __init__(self):
        super().__init__("BearHands", 0, 1, "fist_", 1, 10)
    def Shoot(self,*args):
        if(self.current_ammo == "sword_"):
            sword_swing.play()
        else:
            swing.play()
        super().Shoot(*args)

def GetWeapon(weapon):
    if(weapon == "Regular_Bow"):
        return Regular_Bow
    if(weapon == "gold_coin"):
        return GoldHands
    if(weapon == "fist"):
        return BearHands
    if(weapon == "Cross_Bow"):
        return Cross_Bow
    if(weapon == "Pistol"):
        return Pistol
    if(weapon == "Rifle"):
        return Rifle
    if(weapon == "SniperRifle"):
        return SniperRifle

# 1.4 TerrainFunctions

class Obstacle():

    def __init__(self, span, y, img):
        self.span = span
        self.y = y
        self.baseImg = img
        self.currentImg = img
        self.rect = (span[0], y, span[1] - span[0], img.get_rect().height)

    def BuildObstacle(self):
        for x in range(self.span[0], int(self.span[1] - self.baseImg.get_rect().width),
                       int(self.baseImg.get_rect().width / 2)):
            screen.blit(self.baseImg, (x, self.y))
class StoneWall(Obstacle):
    def __init__(self, span, y):
        super().__init__(span, y, img=stonewall)
        self.traits = ["Solid"]

    def GiveBestPath(self, c):
        if (self.span[0] < c.baseImg.get_rect().width):
            return 1
        if (width - self.span[1] < c.baseImg.get_rect().width):
            return -1
        if math.fabs(c.pos[0] - self.span[0]) <= math.fabs(c.pos[0] - self.span[1]):
            return -1
        return 1
class BlankWall(Obstacle):
    def __init__(self, span, y):
        super().__init__(span, y, img=stonewall)
        self.traits = ["Solid"]

    def GiveBestPath(self, c):
        r = random.randint(1, 4)
        if (r == 1):
            return -1
        if (r == 2):
            return 1
        else:
            return 0
class River(Obstacle):
    def __init__(self, span, y, current=1):
        super().__init__(span, y, img=river)
        self.traits = ["Slow", "Flowing"]
        self.current = current
        self.slow = 0.5

    def Drift(self, object):
        object.pos = (object.pos[0] + self.current, object.pos[1])
class Lake(Obstacle):

    def __init__(self, pos, slow=0.8):
        self.pos = pos
        self.traits = ["Slow"]
        self.slow = slow
        self.baseImg = lake
        self.currentImg = lake
        self.rect = lake.get_rect()

    # OverWrite
    def BuildObstacle(self):
        screen.blit(self.baseImg, self.pos)

def GenerateObstacles():
    return [
        StoneWall((100, 500), 400),
        StoneWall((700, 900), 400),
        River((0, width / 2), 500, 1),
        River((0, width / 2), 550, 2),
        Lake((800, 400), 0.4)
    ]
class Ground():
    def DrawGround():
        for x in range(int(width / grass.get_width()) + 1):
            for y in range(int(height / grass.get_height()) + 1):
                    screen.blit(grass, (x * 100, y * 100))

    def DrawLevel():
        screen.blit(city_skyline, (0,0))
        for x in range(int(width / grass.get_width()) + 1):
            for y in range(1,int(height / grass.get_height()) + 1):
                if(y<=7):
                    screen.blit(drak_grass, (x * 100, y * 100))
                elif(y>7):
                    screen.blit(gravel,(x*100,y*100))

    def DrawGround2(y1= 7):
        screen.blit(city_skyline, (0,0))
        for x in range(int(width / grass.get_width()) + 1):
            for y in range(1,int(height / grass.get_height()) + 1):
                if (y<y1):
                    screen.blit(drak_grass, (x * 100, y * 100))
                else:
                    screen.blit(wood_floor,(x*100,y*100))
def BuildTerrain(player, enteties, mobs,store):
    if(store.running):
        Ground.DrawGround2(7)
    else:
        #Ground.DrawGround()
        Ground.DrawLevel()
    screen.blit(coin, (width - 60, 000))
    screen.blit(castle, (000, 800))
    for mob in mobs:
        mob.BuildMob(player, enteties)
        if (CheckDistance(player.pos, mob.pos)<150) and (CheckDistance(player.pos, mob.pos) >= CheckDistance(mob.toggle_spot, mob.pos)-20):
            mob.DrawToggleZone()
            player.toggled = mob
        else:
            if(player.toggled is not None):
                if(CheckDistance(player.pos,player.toggled.pos) < 200):
                    pass
                else:
                    player.toggled = None
        if(type(mob) is Amiad):
            dummy = mob.store.CheckForDummyInteraction(player)
            if (dummy is not None):
                player.toggled = dummy
                dummy.DrawToggleZone()

    for entity in enteties:
        entity.BuildObstacle()

# 1.5 Mobs
class Bag():
    def __init__(self, Weapons, Mobs):
        self.Weapons = Weapons
        self.indexW = 0
        self.Mobs = Mobs
        self.indexM = 0

    def AddWeapon(self, weapon):
        self.Weapons.append(weapon)
    def GetCurrentWeapon(self):
        return self.Weapons[self.indexW]
    def DropWeapon(self, weapon):
        self.Weapons.pop(self.indexW)
        self.indexW = self.indexW % len(self.Weapons)
        return self.Weapons[self.indexW]
    def ChangeWeapon(self, x,player):
        self.indexW = (self.indexW + x) % len(self.Weapons)
        player.current_weapon = self.Weapons[self.indexW]
        player.UpdateBaseImage()

    def AddMob(self, mob):
        self.Mobs.append(mob)
    def ChangeMob(self,player,x=1):
        self.indexM = (self.indexM + x) % len(self.Mobs)
        player.current_mob = self.Mobs[self.indexM]
    def GetCurrentMob(self, player):
        mob = self.Mobs[(self.indexM)]
        return mob
    def CreateCurrentMob(self,player,curser,list_of_enemies,list_of_mobs):
        list_of_prices = [200,600,500] #Hollander, Kabook, Amir
        temp_mob = self.GetCurrentMob(player)
        final_mob = None
        if(temp_mob is Hollander) and player.wallet >= list_of_prices[0]:
           final_mob = temp_mob(player.pos)
           #list_of_mobs.append(final_mob)
           # list_of_mobs.append(temp_mob(player.pos))
           player.UpdateWallet(-1* list_of_prices[0])
        elif(temp_mob is Kabook) and player.wallet >=list_of_prices[1]:
           # list_of_mobs.append(temp_mob(player.pos,curser))
            final_mob = temp_mob(player.pos,curser)
            #list_of_mobs.append(final_mob)
            player.UpdateWallet(-1* list_of_prices[1])
        elif(temp_mob is Amir) and player.wallet >= list_of_prices[2]:
           # list_of_mobs.append(temp_mob(player.pos,list_of_enemies))
            final_mob = temp_mob(player.pos,list_of_enemies)
            #list_of_mobs.append(final_mob)
            player.UpdateWallet(-1*list_of_prices[2])
        return final_mob
class Shop():
    def __init__(self):
        self.bitCoin = 0
        self.shopWalls = BlankWall((000, 2000), 700)
        self.List_of_Weapons = [("Regular_Bow", 100), ("Cross_Bow", 250),("Pistol",500),("Rifle",1000),("SniperRifle",2000)]
        self.List_of_Mobs = [["Hollander,Amir,Kabook"], 0]
        self.gold_hands = GoldHands()
        self.dummy_w = self.SetDummyList()
        self.running = False

    def InvestBitCoin(self, player, amount):
        self.bitCoin += amount
        player.UpdateWallet((-1 * amount))
    def SellBitCoin(self, player):
        if(self.bitCoin >= 500):
            player.UpdateWallet(500)
            self.bitCoin -= 520
    def BitCoinRaise(self):
        self.bitCoin = self.bitCoin * 1.0005
    def BuyWeaponFromShop(self, player, purchase):
        player.UpdateWallet(-1 * purchase[1])
        self.List_of_Weapons.remove(purchase)
        new_weapon = GetWeapon(purchase[0])()
        player.bag.AddWeapon(new_weapon)

    def SetDummyList(self):
        index = 0
        dummy_list = []
        for weapon in self.List_of_Weapons:
            dummy_list.append(WeaponDummy((250+100*index,750),weapon))
            index +=1
        return dummy_list
    def DrawDummies(self):
        if(self.dummy_w is not None):
            for dummy_ in self.dummy_w:
                dummy_.DrawDummy()
    def CheckForDummyInteraction(self,player):
        if (self.dummy_w is None):
            return None
        else:
            for dummy_ in self.dummy_w:
                if (self.running) and (CheckDistance(player.pos,dummy_.pos) <= 150) and (player.pos[1] > dummy_.pos[1]) and (math.fabs(player.pos[0] - dummy_.pos[0]) <= 70):
                    return dummy_
            return None
class Dummy():
    def __init__(self, pos, hp=20):
        self.pos = pos
        self.hp = hp
        self.toggleImg = pygame.image.load("resources/images/toggle_dummy.png")
    def GetHit(self, dmg):
        self.hp -= dmg
        return self.hp > 0
    def ToggleF(self,player):
        pass
    def ToggleB(self,*args):
        pass
    def ToggleG(self,*args):
        pass
    def DrawToggleZone(self):
        screen.blit(self.toggleImg, self.toggle_pos)
class WeaponDummy(Dummy):
    def __init__(self, pos, weapon):
        super().__init__(pos)
        self.weapon = weapon
        self.toggle_pos = (pos[0],pos[1]+100)

    def Switch(self, newWeapon):
        self.weapon = newWeapon
        self.hp = 20
    def DrawDummy(self):
        img = weapon_seller
        screen.blit(img, self.pos)
        if(self.weapon is not None):
            img_w = pygame.image.load("resources/images/Weapons/"+self.weapon[0]+".png")
            screen.blit(img_w,(self.pos[0]+15,self.pos[1]+73))
    def ToggleB(self,player,store):
        if(self.weapon is not None):
            store.BuyWeaponFromShop(player,self.weapon)
            self.weapon = None

class Mob():
    def __init__(self, pos, baseImg, hp,vel = 0):
        self.pos = pos
        self.baseImg = baseImg
        self.currentImg = baseImg
        self.hp = hp
        self.rect = baseImg.get_rect()
        self.interactionPos = (0, 0)
        self.vel = vel
        self.toggle_spot = (000.000)
    def BuildMob(self):
        screen.blit(self.currentImg, self.pos)
    def DrawToggleZone(self):
        pass
    def ToggleF(self,junk1=0):
        pass
    def ToggleB(self,junk1=0,junk2=0):
        pass
    def ToggleG(self,*args):
        pass
class Amiad(Mob):
    def __init__(self, pos,store):
        super().__init__(pos, amiad_head, hp=200)
        self.pos = pos
        self.staticImg = amiad_body
        x, y = (self.pos[0], self.pos[1] + 45)
        w, h = self.staticImg.get_rect()[2:4]
        self.rect = (x, y, w + 60, h + 30)
        self.toggle_pos = (100, 900)
        self.toggle_spot = (100, 900)
        self.store = store
        self.stillToggled = False
        self.toggleImg = toggle

    def TrackPlayer(self, player):
        angel = GetAngle(self.pos, player.pos)
        self.currentImg = RotateImgTowardsPlayer(player.pos, self.pos, self.baseImg)[0]
    def BuildMob(self, player, obsticles):
        self.TrackPlayer(player)
        temp = (self.pos[0], self.pos[1] + 45)
        screen.blit(self.staticImg, temp)
        screen.blit(self.currentImg, self.pos)
        self.store.BitCoinRaise()
        if (self.stillToggled):
            self.DrawShop(obsticles)
        else:
            self.ExitShop(obsticles)
    def DrawBitCoin(self):
        font = pygame.font.Font(None, 45)
        survivedtext1 = font.render(str(int(self.store.bitCoin)).zfill(2), True, (0, 0, 0))
        textRect = survivedtext1.get_rect()
        textRect.topright = [ 1830, 120]
        screen.blit(survivedtext1, textRect)
        screen.blit(bit_Coin,(1850,110))
    def DrawShop(self, obsticles):
        self.store.running = True
        if (self.store.shopWalls in obsticles):
            pass
        else:
            obsticles.append(self.store.shopWalls)
        if not (self.store.gold_hands in player.bag.Weapons):
            player.bag.AddWeapon(self.store.gold_hands)
        self.store.DrawDummies()
    def ExitShop(self, obsticles):
        self.store.running = False
        if (self.store.shopWalls in obsticles):
            obsticles.remove(self.store.shopWalls)
        if  (self.store.gold_hands in player.bag.Weapons):
            player.bag.Weapons.remove(self.store.gold_hands)

    def DrawToggleZone(self):
        screen.blit(self.toggleImg, self.toggle_pos)
        self.DrawBitCoin()
    def ToggleF(self,junk1=0):
        if player.wallet >= 10:
            self.store.InvestBitCoin(player, 10)
            self.DrawBitCoin()
    def ToggleB(self, junk1=0,junk2=0):
        if click.CheckB():
            self.stillToggled = not self.stillToggled
    def ToggleG(self,player):
        amiad_sound.play()
        self.store.SellBitCoin(player)
class Omer(Mob):
    def __init__(self,pos):
        super().__init__(pos,omer,hp=200)
        self.funds = 0
        self.nextDiscovery = 150
        self.upgrade_ready = 0
        self.staticImg = omer_chair
        x, y = (pos[0], pos[1] + 45)
        w, h = self.staticImg.get_rect()[2:4]
        self.rect = (x, y, w + 60, h + 30)
        self.toggle_pos = (self.pos[0], self.pos[1]-140)
        self.toggle_spot = (self.pos[0]-50, self.pos[1])
        self.toggleImg = omer_board
        self.vel = 2
        self.yamero = 0

    def GetFunds(self,donation):
        self.funds += donation
    def Reaserch(self):
        if(self.funds < self.nextDiscovery):
            self.funds = self.funds * 1.005
        else:
            omer_discovery_sound.play()
            self.funds -= self.nextDiscovery
            self.nextDiscovery = self.nextDiscovery *1
            self.upgrade_ready += 1

    def UpgradeWeapon(self,player):
        omer_sound.play()
        current_ammo = player.current_weapon.current_ammo
        better_ammo = self.UpgradeAmmo(current_ammo)
        player.current_weapon.current_ammo = better_ammo
        if (better_ammo == "luffy_"):
            yamete.play()
            self.yamero = 10
    def UpgradeAmmo(self,ammo):
        list_of_upgrades=[["arrow","gold_arrow","strong_arrow","flaming_arrow"],
                          ["fist_","bat_","sword_","axe_","luffy_"],
                          ["gold_coin","blue_cheese","gold_bar"],
                          ["regular_bullet","gold_bullet","strong_bullet","pearsing_bullet"]]
        for type_ in list_of_upgrades:
            if(ammo in type_):
                index = type_.index(ammo)
                if(index + 1 < len(type_)):
                    return type_[index + 1]
        return ammo
    def DrawFunds(self):
        font = pygame.font.Font(None, 45)
        survivedtext = font.render(str(int(self.funds)).zfill(2), True, (0, 0, 0))
        textRect = survivedtext.get_rect()
        textRect.topright = [ 1830, 120]
        screen.blit(survivedtext, textRect)
        screen.blit(omer_logo,(1850,110))
    def BuildMob(self, player, junk1):
        temp = (self.pos[0], self.pos[1]-70)
        screen.blit(self.staticImg, temp)
        screen.blit(self.currentImg, self.pos)
        self.Reaserch()
    def DrawToggleZone(self):
        screen.blit(self.toggleImg, self.toggle_pos)
        self.DrawFunds()
        #self.currentImg = omer_toggled
        x = random.randint(0, 100)
        if(x == 1):
            self.currentImg = omer_toggled
        elif(x <= 2):
            self.currentImg = omer


    def ToggleF(self,player):
        if (Clickers.GetClick(click)%2 == 0):
            self.baseImg = omer_toggled
        elif(Clickers.GetClick(click)%2 == 1):
            self.baseImg = omer
        if(player.wallet >= 7):
            player.UpdateWallet(-7)
            self.funds += 7

    def ToggleB(self,player,junk2):
        if click.CheckB() and self.upgrade_ready > 0:
            self.UpgradeWeapon(player)
            self.upgrade_ready -= 1
    def ToggleG(self,*args):
        pass
def GenerateListOfMobs(store):
    return [
        Amiad((000, 900),store),
        Omer((1720,880))
    ]

# 1.8 - MovementTrackingfunctions
def GetObjectPos(img, object1, object2):
    angle = math.atan2(object2[1] - (object1[1] + 32), object2[0] - (object1[0] + 26))
    objectRot = pygame.transform.rotate(img, 360 - angle * 57.29)
    objectPos1 = (object1[0] - objectRot.get_rect().width / 2, object1[1] - objectRot.get_rect().height / 2)
    return (objectRot, objectPos1)
def GetAngle(object1, object2):
    return math.atan2(object2[1] - (object1[1] + 32), object2[0] - (object1[0] + 26))
def IfInbound(object1):
    if (object1[0] < 0 or object1[0] > width-20):
        return False
    if (object1[1] < 100 or object1[1] > height-20):
        return False
    return True
def GetMovementVector(angle, constVel):
    velx = math.cos(angle) * constVel
    vely = math.sin(angle) * constVel
    return (velx, vely)
def GetRotatedImg(angle, img):
    img1 = pygame.transform.rotate(img, 360 - angle * 57.29)
    return img1
def RotateImgTowardsPlayer(playerPos, objectPos, img):
    return GetObjectPos(img, objectPos, playerPos)

# LocationFunctions
def MoveObject1TowordsObject2(badguy, objectPos, vel, objectSize=40):
    if (math.fabs(badguy[0] - objectPos[0]) < objectSize) and (math.fabs(badguy[1] - objectPos[1]) < objectSize):
        return badguy
    angle = GetAngle(badguy, objectPos)
    velx, vely = GetMovementVector(angle, vel)
    newX = badguy[0] + velx
    newY = badguy[1] + vely
    return (newX, newY)
def CheckForCollision(object1, object2):
    if(object1 is not None) and (object2 is not None):
        rect1 = pygame.Rect(object1.currentImg.get_rect())
        rect1.top = object1.pos[1]
        rect1.left = object1.pos[0]

        rect2 = pygame.Rect(object2.currentImg.get_rect())
        rect2.top = object2.pos[1]
        rect2.left = object2.pos[0]

        return rect1.colliderect(rect2)
    return False
def CheckForCollisionObject(object1, obsticle):
    rect1 = pygame.Rect(object1.currentImg.get_rect())
    rect1.top = object1.pos[1]
    rect1.left = object1.pos[0]

    return rect1.colliderect(obsticle.rect)
def CheckForCollisionCircle(object1, obsticle):
    delta = ((object1.pos[0] - obsticle.pos[0] - obsticle.rect[2] / 2) ** 2 + (
                object1.pos[1] - obsticle.pos[1] - obsticle.rect[3] / 2) ** 2) ** 0.5
    if delta < max(obsticle.rect[2] / 2, obsticle.rect[3] / 2):
        return True
    return False
def CheckDistance(point1, point2):
    delta_x_squared = (point1[0] - point2[0]) ** 2
    delta_y_squared = (point1[1] - point2[1]) ** 2
    return ((delta_x_squared + delta_y_squared) ** 0.5)

# DrawingFunctions
def DrawCharacterPos(Character, currentPos, wantedPos):
    MoveObject1TowordsObject2(currentPos, wantedPos, Character.vel)
def DrawClock():
    max_time = 180000
    font = pygame.font.Font(None, 40)
    survivedtext = font.render(str(int(((max_time - pygame.time.get_ticks()) / 60000))) + ":" + str(
        int((max_time - pygame.time.get_ticks()) / 1000 % 60)).zfill(2), True, (255, 255, 255))
    textRect = survivedtext.get_rect()
    textRect.topright = [width - 5, 70]
    screen.blit(survivedtext, textRect)
def DrawWallet():
    font = pygame.font.Font(None, 45)
    survivedtext = font.render(str(player.wallet).zfill(2), True, (0, 0, 0))
    textRect = survivedtext.get_rect()
    textRect.topright = [width - 65, 20]
    screen.blit(survivedtext, textRect)
def DrawHealthBar(player):
    screen.blit(healthbar, (5, 5))
    for health1 in [x for x in range(player.hp) if x%2 == 0]:
        screen.blit(health, (health1/2 + 8, 8))
def DrawMobLogo(player):
    pos_ = (1850,160)
    temp = player.current_mob
    if(temp is Hollander):
        screen.blit(hollander_logo,pos_)
    elif(temp is Kabook):
        screen.blit(kabook_logo,pos_)
    elif(temp is Amir):
        screen.blit(amir_logo,pos_)
def DrawEveryThing(current_time,player,obstacles,mobs,store,projectiles,badguys,goodguys,position):
    if(current_time % 2 == 1):
        screen.fill(0)
        BuildTerrain(player,obstacles,mobs,store)
        for L in projectiles,badguys,goodguys:
            for entity in L:
                entity.Draw()
        if (mobs[1].yamero > 0):
            for z in [x for x in badguys if not (type(x) is Thombstone)]:
                z.GetHit(5)
            if (mobs[1].yamero >= 5):
                screen.blit(yamero_small, (000, 000))
            else:
                screen.blit(yamero_big, (000, 000))
            mobs[1].yamero -= 1
        screen.blit(player.currentImg, player.pos)
        # 6.4 - Draw clock,wallet,heath-bar
        DrawClock()
        DrawWallet()
        DrawHealthBar(player)
        DrawMobLogo(player)
        screen.blit(game_curser, position)
        pygame.display.flip() 





# 2 - Initialize the game

pygame.init()
width, height = 1900, 1000
screen = pygame.display.set_mode((width, height))
keys = [False, False, False, False, False, False, False, False, False, False, False]
player = MainPlayer(width, height)
acc = [0, 0]
projectiles = []
main_store = Shop()
mobs = GenerateListOfMobs(main_store)
obstacles_list = GenerateObstacles()
thombstones = [Thombstone([200,200]),Thombstone([300,200]),Thombstone([400,200]),Thombstone([1400,150]),Thombstone([1200,100]),Thombstone([1700,400])]
badguys = thombstones+[Zombie([950, 300])]
list_of_amirs = [Amir((300,600),badguys)]
list_of_amirs[0].hp = 200
goodguys = []
pauseVal = False
click = Clickers()
time = Time()
pygame.display.set_icon(game_icon)
pygame.display.set_caption('"WinDoW_TitLE:"')
pygame.mouse.set_visible( False )

# 4 - keep looping through
running = 1
exitcode = 0
while running:
    position = pygame.mouse.get_pos()
    DrawEveryThing(time.clock,player,obstacles_list,mobs,main_store,projectiles,badguys,goodguys+list_of_amirs,position)
    time.Tick()

    player.UpdateCurrImage(position)
    # 6.3 - Generate Zombies - All MoveObjects
    for t in thombstones:
        if(t.hp <= 0):
            thombstones.remove(t)
        else:
            z = t.GenerateZombie()
            if(z is not None):
                badguys.append(z)
    for L in badguys,goodguys,list_of_amirs:
        for guy in L:
            guy.move(player.pos, obstacles_list+list_of_amirs)
            # 6.3.1 - Attack player
            if (CheckForCollision(guy, player)):
                guy.hit(player)
            if(type(guy) is Amir):
                if not (guy.target is None):
                    if(CheckDistance(guy.pos,guy.GetCurrentTarget().pos)<=100) and (not guy.GetCurrentTarget().pause):#if(CheckForCollision(guy,guy.GetCurrentTarget())):
                        guy.hit(guy.GetCurrentTarget())
            if(type(guy) is Kabook):
                for enemy1 in badguys:
                    if(CheckDistance(guy.pos,enemy1.pos) <= 150):
                        guy.hit(enemy1)
                        sword_swing.play()

            # 6.3.2 - Check for hits for Projectiles
            index1 = 0
            for bullet in projectiles:
               if not (bullet.move(obstacles_list, projectiles,L,index1)):
                   index1 +=1
            # 6.3.3 - Next bad guy
        for guy in L:
            if(guy.hp > 0):
                time.DoTick(guy)
            else:
                player.UpdateWallet(guy.rate)
                L.remove(guy)
        time.DoTick(player)

    # 8 - loop through the events
    eventTimer = 0
    for event in pygame.event.get():
        eventTimer += 1
        # check if the event is the X button
        if event.type == pygame.QUIT:
            # if it is quit the game
            pygame.quit()
            exit(0)
        if event.type == pygame.KEYDOWN:
            if event.key == K_w:
                keys[0] = True
            elif event.key == K_a:
                keys[1] = True
            elif event.key == K_s:
                keys[2] = True
            elif event.key == K_d:
                keys[3] = True
            elif event.key == K_f:
                keys[4] = True
            elif event.key == K_q:
                keys[5] = True
            elif event.key == K_e:
                keys[6] = True
            elif event.key == K_g:
                keys[7] = True
            elif event.key == K_1:
                keys[8] = True
            elif event.key == K_2:
                keys[9] = True
            elif event.key == K_b:
                keys[-1] = True
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_w:
                keys[0] = False
            elif event.key == pygame.K_a:
                keys[1] = False
            elif event.key == pygame.K_s:
                keys[2] = False
            elif event.key == pygame.K_d:
                keys[3] = False
            elif event.key == pygame.K_f:
                keys[4] = False
            elif event.key == pygame.K_q:
                keys[5] = False
            elif event.key == pygame.K_e:
                keys[6] = False
            elif event.key == pygame.K_g:
                keys[7] = False
            elif event.key == pygame.K_1:
                keys[8] = False
            elif event.key == pygame.K_2:
                keys[9] = False
            elif event.key == pygame.K_b:
                keys[-1] = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            position = pygame.mouse.get_pos()
            if(player.current_weapon.IsReloading()):
                player.current_weapon.Reload()
            else:
                if(player.current_weapon.current_magazine <= 0):
                    player.current_weapon.StartReloading()
                else:
                    newProj = player.current_weapon.Shoot(player,position,projectiles)
    # 9 - Move player
    click.Click()
    if keys[0]:
        click.Click()
        player.UpdatePos(0, -player.current_vel, obstacles_list)
    elif keys[2]:
        click.Click()
        player.UpdatePos(0, player.current_vel, obstacles_list)
    if keys[1]:
        click.Click()
        player.UpdatePos(-player.current_vel, 0, obstacles_list)
    elif keys[3]:
        click.Click()
        player.UpdatePos(player.current_vel, 0, obstacles_list)
    if keys[4] and player.toggled is not None:
        click.Click()
        player.toggled.ToggleF(player)
    if keys[5]:
        if(click.CheckQ()):
            player.bag.ChangeWeapon(-1,player)
    if keys[6]:
        if(click.CheckE()):
            player.bag.ChangeWeapon(1,player)
    if keys[7]:
        if(click.CheckG()):
            if not (player.toggled is None):
                player.toggled.ToggleG(player)
    if keys[8]:
        if(click.Check1()):
            player.bag.ChangeMob(player,1)
    if keys[9]:
        if(click.Check2()):
            temp_mob = player.bag.GetCurrentMob(player)
            temp_mob2 = player.bag.CreateCurrentMob(player, pygame.mouse.get_pos(), badguys, goodguys)
            if not (temp_mob2 is None):
                if(temp_mob is Amir):
                    list_of_amirs.append(temp_mob2)
                else:
                    goodguys.append(temp_mob2)

    if keys[-1] and player.toggled is not None:#B
        click.Click()
        player.toggled.ToggleB(player,main_store)

   #10 - Win/Lose check
    if len(thombstones) == 0:
        running = 0
        exitcode = 1
    if pygame.time.get_ticks()>=180000:
        running=0
        exitcode=1
    if player.hp<=0:
        running=0
        exitcode=0
# 11 - Win/lose display
t_.sleep(0.1)
if exitcode==0:
    screen.blit(defeat, (0,0))
    defeat_sound.play()
else:
    screen.blit(victory, (0,0))
    victory_sound.play()

while 1:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit(0)
    pygame.display.flip()
